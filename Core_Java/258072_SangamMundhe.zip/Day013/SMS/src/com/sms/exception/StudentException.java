package com.sms.exception;

@SuppressWarnings("serial")
public class StudentException extends Exception {
	public StudentException(String message) {
		super(message);
	}
}
