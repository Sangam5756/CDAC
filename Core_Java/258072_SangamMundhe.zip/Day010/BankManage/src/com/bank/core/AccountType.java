package com.bank.core;

public enum AccountType {
	SAVING, CURRENT
}
