package com.custome_exceptions;

@SuppressWarnings("serial")
public class BaseException extends Exception {

	public BaseException(String message) {
		super(message);
	}


}
