package com.custome_exceptions;

public class BankException extends BaseException {

	public BankException(String message) {
		super(message);

	}

}
