Day 1
1. Refer to "Installation Instructions" & complete the same.

2. MUST go through "day1_help\day1_notes.rtf" and  from day1-data\day1_help
\day1_notes 
(only till whatever  we have covered)

3. Go through  code samples from day1-data\code\src

4. Solve (Hands on)

4.0
Accept 5 doubles from user (scanner)
Print it's average.

After creating PrintAverage.java (under day1_lab\src)
Open cmd prompt from the same src folder
To compile
javac -d ..\bin PrintAverage.java
cd ..\bin
To run 
java PrintAverage


4.1 Write Java program - 
Display food menu to user. User will select items from menu along with the quantity. (eg 1. Dosa 2. Samosa 3. Idli ... 0 . Generate Bill ) Assign fixed prices to food items(hard code the prices)
When user enters 'Generate Bill' option(0) , display total bill & exit.

OR
Write Java program for the following - 
It should  run till user enters any other option than add or sub or multiply or divide
Prompt user to enter the input operation : (add|subtract|multiply|divide) & 2 numbers(double)
Display the result of the operation.
Use Scanner for accepting all inputs from user. 
Hint : use switch-case

5. Reading home work 
Please read 
"day1_data\day1_help\day1_notes.pdf"

