package com.shopify.core;

public enum Category {
	ELECTRONICS, CLOTHING, GROCERY, BOOKS

}
