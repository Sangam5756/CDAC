package com.shopify.exceptions;

@SuppressWarnings("serial")
public class ECommerceException extends Exception {

	public ECommerceException(String message) {
		super(message);

	}

}
