package com.app.core;

public enum Subject {
	JAVA, PYTHON, DBT, REACT, ANGULAR, SE,CS
}
