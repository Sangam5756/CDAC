package com.hashset.core;

public enum Category {
	FOOD, OIL, FRUIT, STATIONARY, SPICES, GRAINS
}
