                    Assignment 1
				      Git

Q.1.  Create a directory by name demo on Windows machine.. Initialize it as a git repository. Create a file by name index.html in it. Git add and git commit. Create a new file by name product.html. git add and git commit. Check with git log and git status.


Q.2. Create a directory by name project1 on your Windows machine. Initialize it as a git repository. Create a file by name file1.c in it. Type “Welcome to git!!!” in the file. Git add and git commit. Modify the file1.c again and add second line “Welcome to DevOPS!!!”. Git add and git commit. Modify the file1.c again and add Third line “Welcome to Jenkins!!!”. Git add and git commit. Now try to get back the file1.c with one line “Welcome to git!!!” from commit.

Q.3.  Go to the demo directory created in Q.1. Check git status. Create a branch by name UI. Go to the branch and create a file by name ui.html. Git add and commit. Go to the master branch. Create another branch by name dbconn. Go to the branch and create user-reg.html file. Git add and commit. Now go to the master branch. Merge the UI branch first. Then merge the dbconn branch.

Q.4. Go to GitHub. Create a repository. Create a file by name test.c in it. Commit changes. Now on your computer create a directory by name remote. Go to the directory. Clone the GitHub repository. Now go the new directory created after clone. Create a new file by name demo.c. git add and commit. Then git push . Now go to the GitHub and check if the demo.c file is shown.

Q.5. Go to the GitHub. Create a new blank repository by dac-proj name.
Create a directory by name demo1 on your Windows machine. Initialize it as a git repository. Create a file by name index.html in it. Git add and git commit. Create a new file by name product.html. git add and git commit. Check with git log and git status. Now link this local repository to the GitHub repository using remote add origin command. Then git push. Go to GitHub repository and check if the local files are shown.
