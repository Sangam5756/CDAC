Q.1.  Create a directory by name demo on Windows machine.. Initialize it as a git repository. Create a file by name index.html in it. Git add and git commit. Create a new file by name product.html. git add and git commit. Check with git log and git status.



git init

touch  index.html

git add .
git commit -m "commiting the index.html"

touch product.html

git add .
git commit -m "commit product.html"
git log 
git status

