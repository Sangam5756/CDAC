echo "Enter the First Number"
read num1

echo "Enter the Second Number"
read num2

ans=$((num1 + num2 ))
echo "$ans"
