read n1
read n2

temp=$n1
n1=$n2
n2=$temp

echo "$n1"
echo "$n2"
