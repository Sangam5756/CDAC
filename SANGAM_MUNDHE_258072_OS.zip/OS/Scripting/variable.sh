name="sangam"
age=22
echo "Name is $name"
echo "Age is $age"
