echo "first argument $1"
echo "second argument $2"
echo "third argument $3"
echo "oth argument is $0"
echo "-1 argument $-0"


echo "use the @ for all argument $@"

$1
$2
