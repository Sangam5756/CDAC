echo "Enter the name"
read name

echo "Welcome $name to the shell script"
