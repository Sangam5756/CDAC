read n
for i in {1.."$n"}
do
echo "Number is: $i"
done
