read name
if [ "$name" = "Sangam" ]; then
echo "Admin User"
fi

