#!/bin/bash

echo "hello sangam"
