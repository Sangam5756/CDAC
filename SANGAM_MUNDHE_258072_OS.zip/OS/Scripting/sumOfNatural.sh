read n

ans=$(((n * (n+1))/2))

echo "$ans"
