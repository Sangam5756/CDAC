package com.book.exception;

@SuppressWarnings("serial")
public class BooksException extends Exception{
	
	public BooksException(String message) {
		super(message);
	}

}
