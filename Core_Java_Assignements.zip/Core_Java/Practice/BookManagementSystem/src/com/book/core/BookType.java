package com.book.core;

public enum BookType {
		FICTION ,NONFICTION ,SCIENCE ,HISTORY
}
