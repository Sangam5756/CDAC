package com.book.core;

public enum BookFormat {
		PDF, DOC,TEXT
}
