package com.shoe.exception;

public class ShoeException extends Exception {
	public ShoeException(String msg) {

		super(msg);
	}

}
