package com.shoe.exception;

public class InvalidDataException extends ShoeException {

	public InvalidDataException(String msg) {
		super(msg);

	}

}
