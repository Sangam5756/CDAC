package com.shoe.core;

public enum ShoeType {FORMAL,CASUAL,SPORTS}
