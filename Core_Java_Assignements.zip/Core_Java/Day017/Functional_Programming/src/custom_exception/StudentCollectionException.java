package custom_exception;

public class StudentCollectionException extends Exception {

	public StudentCollectionException(String message) {
		super(message);
	}

	
}
