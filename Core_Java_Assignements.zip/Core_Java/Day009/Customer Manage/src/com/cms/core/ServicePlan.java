package com.cms.core;

public enum ServicePlan {
	SILVER(1000),
	GOLD(2000),
	DIAMOND(5000),
	PLATINUM(10000);

	ServicePlan(int i) {
		// TODO Auto-generated constructor stub
	}	
}
