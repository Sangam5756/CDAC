import * as calc from './calc.js';

console.log('add(2,3)=', calc.add(2,3));
console.log('subtract(5,2)=', calc.subtract(5,2));
console.log('multiply(4,6)=', calc.multiply(4,6));
console.log('divide(10,2)=', calc.divide(10,2));
console.log('square(5)=', calc.square(5));
console.log('sum(1,2,3,4)=', calc.sum(1,2,3,4));