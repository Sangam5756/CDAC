export function isEquilateral(a, b, c) {
  return a === b && b === c;
}
export function calcPerimeter(a, b, c) {
  return a + b + c;
}