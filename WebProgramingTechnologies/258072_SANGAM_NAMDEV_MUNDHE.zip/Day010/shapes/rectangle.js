export function calcArea(length, breadth) {
  return length * breadth;
}
export function calcPerimeter(length, breadth) {
  return 2 * (length + breadth);
}