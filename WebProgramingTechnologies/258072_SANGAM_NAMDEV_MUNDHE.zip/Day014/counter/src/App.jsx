import './App.css'
import Counter from './components/Counter'
import Counter2 from './components/Counter2'




const App = () => {

  return (

    <div>
      
      <Counter2 />

    </div>
  )
}

export default App
